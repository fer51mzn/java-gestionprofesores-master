/*package com.piramide.dao;

import com.piramide.dao.ofertas.DAOOfertas;
import com.piramide.dao.ofertas.DAOOfertasSQL;

public class DAOFactory {
    private static DAOFactory daoFactory;
    private DAOOfertas daoOfertas;

    private DAOFactory(){}

    public static DAOFactory getInstance() {
        if(daoFactory == null){
            daoFactory = new DAOFactory();
        }
        return daoFactory;
    }

    public DAOOfertas getDAOOfertas() {
        if(this.daoOfertas == null){
            daoOfertas = new DAOOfertasSQL();
        }
        return daoOfertas;
    }
}*/
