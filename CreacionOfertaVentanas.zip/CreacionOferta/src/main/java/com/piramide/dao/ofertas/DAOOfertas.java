/*package com.piramide.dao.ofertas;


import com.piramide.entities.Oferta;

public interface DAOOfertas {
    public Boolean exists(String tipoEmpleo);
    public Boolean alta(Oferta oferta);
    public List<Oferta> lista();
}
*/