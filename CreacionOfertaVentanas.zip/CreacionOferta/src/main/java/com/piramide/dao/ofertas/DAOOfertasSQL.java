/*package com.piramide.dao.ofertas;


import com.piramide.db.DBConnection;
import com.piramide.entities.Oferta;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;



public class DAOOfertasSQL implements DAOOfertas {
    @Override
    public Boolean exists(String id) {
        try{
            Statement statement = DBConnection.getInstance().createStatement();
            ResultSet resultSet = statement.executeQuery(
                    "select count(*) as numOfertas " +
                            "from ofertas where id = '"+id+"'");
            while (resultSet.next()){
                int numOfertas = resultSet.getInt("numOfertas");
                if(numOfertas == 0){
                    return false;
                }
                else return true;
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return null;
    }

    @Override
    public Boolean alta(Oferta oferta) {
        try {
            Statement statement = DBConnection.getInstance().createStatement();
            statement.execute("" +
                    "insert into ofertas (id,tipoEmpleo,requisitos,salario) " +
                    "values ('"+oferta.getId()+"','"+oferta.getTipoEmpleo()+"','"+oferta.getRequisitos()+"','"+oferta.getSalario()+"')");
        } catch (SQLException exception) {
            //SQLError duplicate PK
            if(exception.getErrorCode() == 1062){
                System.err.println("Ya existe una oferta con estos requisitos");
            }
            else {
                System.err.println(exception.getMessage());
            }
            return false;
        }
        return true;
    }

    @Override
    public List<Oferta> lista() {
        List<Oferta> ofertas = new ArrayList<>();
        try{
            Statement statement = DBConnection.getInstance().createStatement();
            ResultSet resultSet = statement.executeQuery("" +
                    "select * from ofertas o join empresa e on e.cif = o.id");
            while (resultSet.next()){
                //datos de la oferta
                String id = resultSet.getString("id");
                String tipoEmpleo = resultSet.getString("tipoEmpleo");
                String requisitos = resultSet.getString("rquisitos");
                //compruebo en la lista si existe un oferta con esos requisitos
                Oferta oferta = null;
                Boolean existe = false;
                /*
                for (int i = 0; i < profesores.size(); i++) {
                    Profesor actual = profesores.get(i);
                    if(actual.getEmail().equals(email)){
                        profesor = actual;
                        existe = true;
                        break;
                    }
                }
                 */
/*
                Optional<Oferta> posibleOferta = ofertas.stream().filter(actual->{
                    return actual.getId().equals(id);
                }).findFirst();
                if(posibleOferta.isPresent()){
                    oferta = posibleOferta.get();
                    existe = true;
                }
                if(oferta == null){
                    oferta = new Oferta(id,tipoEmpleo,requisitos);
                }
                //modulo
                String nombreEmpresa = resultSet.getString("modulo");
                String nombreCiclo = resultSet.getString("ciclo");
                int horas = resultSet.getInt("horas");
                Ciclo ciclo = null;
                ciclo = Ciclo.valueOf(nombreCiclo);
                Modulo modulo = new Modulo(nombreModulo,ciclo);
                profesor.add(modulo,horas);
                if(!existe) {
                    profesores.add(profesor);
                }
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return profesores;
    }
}
*/