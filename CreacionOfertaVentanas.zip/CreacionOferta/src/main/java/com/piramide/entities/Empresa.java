package com.piramide.entities;

public class Empresa {
}
