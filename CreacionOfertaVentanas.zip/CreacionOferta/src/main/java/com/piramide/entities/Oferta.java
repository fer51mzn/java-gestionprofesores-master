package com.piramide.entities;

public class Oferta {

    private final String id;
    private final float salarioMin;
    private final float salarioMax;
    private final String requisitos;
    private final String puesto;


    public Oferta(float salarioMin, float salarioMax, String requisitos, String puesto) {
        this.salarioMin = salarioMin;
        this.salarioMax = salarioMax;
        this.requisitos = requisitos;
        this.puesto = puesto;
        this.id = null;
    }

    public Oferta(String id, float salarioMin, float salarioMax, String requisitos, String puesto) {
        this.salarioMin = salarioMin;
        this.salarioMax = salarioMax;
        this.requisitos = requisitos;
        this.puesto = puesto;
        this.id = id;
    }

    public float getSalarioMin() {
        return salarioMin;
    }

    public float getSalarioMax() {
        return salarioMax;
    }

    public String getRequisitos() {
        return requisitos;
    }

    public String getPuesto() {
        return puesto;
    }

    public String getId() {
        return id;
    }
}
