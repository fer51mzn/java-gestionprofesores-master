package com.piramide.gui;

import com.piramide.entities.Oferta;
import javax.swing.*;


public class GUIOfertaAlta extends JFrame {
    private JTextField inputPuesto;
    private JLabel infoPuesto;
    private JTextField inputRequisitos;
    private JLabel infoTipoEmpleo;
    private JButton publicarOfertaButton;
    private JPanel root;
    private JTextField inputSalarioMin;
    private JLabel infoRequisito;
    private JLabel infoSalario;
    private JTextField inputSalarioMax;

    public GUIOfertaAlta(){
        setSize(400,400);
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        this.add(root);
        this.setHandlers();
    }

    private void setHandlers(){
        publicarOfertaButton.addActionListener(e->{
            buildOferta();
        });
    }

    private void buildOferta(){
        try {
            String puesto = inputPuesto.getText();
            String requisitos = inputRequisitos.getText();
            float salarioMin = Float.parseFloat(inputSalarioMin.getText());
            float salarioMax = Float.parseFloat(inputSalarioMax.getText());
            Oferta oferta = new Oferta(salarioMin, salarioMax, requisitos,puesto);
        } catch(NumberFormatException ex){
            JOptionPane.showMessageDialog(this,
                    "Error al crear la oferta",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
            inputSalarioMin.setText(null);
            inputSalarioMax.setText(null);

        } catch (Exception e){
            System.out.println(e.getMessage());
        }
    }


}
