package com.piramide.gui;

import com.piramide.entities.Oferta;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class GUIOfertaLista extends  JFrame{

    List<Oferta> ofertas;
    private JPanel root;
    private JTable tableOfertas;

    public GUIOfertaLista(){
        setSize(400,400);
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        this.add(root);

    }


    /*private void buildOfertaLista(){
        try {
            String puesto = inputPuesto.getText();
            Oferta oferta = new Oferta(puesto);
        } catch(NumberFormatException ex){
            JOptionPane.showMessageDialog(this,
                    "Error al crear la oferta",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);


        } catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

    */
    public static class tableOfertas {
        JFrame f;
        public tableOfertas(){
            f=new JFrame();

            List<Oferta> ofertas = new ArrayList<>();
            ofertas.add(new Oferta(400,700,"FP de Jardineria","Jardinero"));
            for(int i=0;i<list.size();i++){
                modelotabla.addRow(new Object[] {list.get(i).getName1(), list.get(i).getCedula(), list.get(i).getAddress(), list.get(i).getGender(), list.get(i).getHobbies()});
            }


            String column[]={"Puesto","Salario","Ciclo"};

            JTable jt=new JTable(ofertas,column);
            jt.setBounds(30,40,200,300);
            JScrollPane sp=new JScrollPane(jt);
            f.add(sp);
            f.setSize(300,400);
            f.setVisible(true);
        }

    }

    private static final long serialVersionUID = 1L;

    public static void main(String[] args) {
        GUIOfertaLista guiOfertaLista = new GUIOfertaLista();

        List<String> ofertas = new ArrayList<String>();
        List<String[]> values = new ArrayList<String[]>();

        ofertas.add("col1");
        ofertas.add("col2");
        ofertas.add("col3");

        for (int i = 0; i < 100; i++) {
            values.add(new String[] {"val"+i+" col1","val"+i+" col2","val"+i+" col3"});
        }

        TableModel tableModel = new DefaultTableModel(values.toArray(new Object[][] {}), ofertas.toArray());
        JTable table = new JTable(tableModel);
        AbstractButton testJFrame = null;
        testJFrame.setLayout(new BorderLayout());
        testJFrame.add(new JScrollPane(table), BorderLayout.CENTER);

        testJFrame.add(table.getTableHeader(), BorderLayout.NORTH);

        testJFrame.setVisible(true);
        testJFrame.setSize(200,200);
    }
}

