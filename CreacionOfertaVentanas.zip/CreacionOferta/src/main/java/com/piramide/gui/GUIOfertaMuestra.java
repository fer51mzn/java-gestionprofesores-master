package com.piramide.gui;

import com.piramide.entities.Oferta;
import javax.swing.*;

public class GUIOfertaMuestra extends JFrame{

    private JPanel root;
    private JTextField inputSalarioMin;
    private JTextField inputSalarioMax;
    private JTextField inputRequisitos;
    private JTextField inputPuesto;

    public GUIOfertaMuestra(Oferta oferta){
        setSize(400,400);
        inputSalarioMin.setText(String.valueOf(oferta.getSalarioMin()));
        inputSalarioMax.setText(String.valueOf(oferta.getSalarioMax()));
        inputRequisitos.setText(oferta.getRequisitos());
        inputPuesto.setText(oferta.getPuesto());

        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        this.add(root);
    }


}
