import com.piramide.entities.Oferta;
import com.piramide.gui.GUIOfertaAlta;
import com.piramide.gui.GUIOfertaLista;
import com.piramide.gui.GUIOfertaMuestra;

public class Main {
    public static void main(String[] args) {
        GUIOfertaAlta guiOfertaAlta = new GUIOfertaAlta();
        guiOfertaAlta.setVisible(true);

        Oferta oferta = new Oferta(900,1000,"FP", "jardinero");
        GUIOfertaMuestra ofertaMuestra = new GUIOfertaMuestra(oferta);
        ofertaMuestra.setVisible(true);

        GUIOfertaLista guiOfertaLista = new GUIOfertaLista();
      //  guiOfertaLista.setVisible(true);
        new GUIOfertaLista.tableOfertas();
    }
}
