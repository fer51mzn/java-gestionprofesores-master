# Offer Form

- [ ] Create Offer entity
- [x] Create high bid GUI
- [x] Create GUI sample offer

Program to display user offers and create new offers. windows created with Swing

`Class`
